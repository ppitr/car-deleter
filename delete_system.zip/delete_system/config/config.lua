--░█████╗░██████╗░████████╗██╗░░██╗  ██████╗░███████╗██╗░░░██╗
--██╔══██╗██╔══██╗╚══██╔══╝╚██╗██╔╝  ██╔══██╗██╔════╝██║░░░██║
--██║░░╚═╝██████╔╝░░░██║░░░░╚███╔╝░  ██║░░██║█████╗░░╚██╗░██╔╝
--██║░░██╗██╔══██╗░░░██║░░░░██╔██╗░  ██║░░██║██╔══╝░░░╚████╔╝░
--╚█████╔╝██║░░██║░░░██║░░░██╔╝╚██╗  ██████╔╝███████╗░░╚██╔╝░░
--░╚════╝░╚═╝░░╚═╝░░░╚═╝░░░╚═╝░░╚═╝  ╚═════╝░╚══════╝░░░╚═╝░░░

Config = {}

Config.Locale = "cs" -- Language / Jazyk [EN/CS]
Config.Minutes = 10 -- Time in minutes / Čas v minutách [DEFAULT - 25]

--𝗡𝗢𝗧𝗜𝗙𝗜𝗖𝗔𝗧𝗜𝗢𝗡 𝗦𝗘𝗧𝗧𝗜𝗡𝗚𝗦--
Config.OxNotifyIcon = "BAN" -- [DEFAULT - BAN]
Config.OxNotifyPosition = "top-right" -- [DEFAULT - TOP]
Config.OxNotifyTitle = "Odtahovka" -- -- [DEFAULT - SERVER]

Config.Timer5MINUTES = 'Všechny vozidla bez řidiče budou smazána za 5 minut'
Config.Timer1MINUTE = 'Všechny vozidla bez řidiče budou smazána za 1 minutu!'
Config.Timer10SECONDS = 'Všechny vozidla bez řidiče budou smazána za 10 sekund!'
Config.Timer5SECONDS = 'Všechny vozidla bez řidiče budou smazána za 5 sekund!'
Config.VehiclesDeleted = 'Všechny vozidla bez řidiče smazána'