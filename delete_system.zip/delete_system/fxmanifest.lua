fx_version 'cerulean'
game 'gta5'

author 'pitr'
description 'Car deleter'
version '1.0'


server_scripts {
    'server/main.lua',
}

shared_scripts {
	'@ox_lib/init.lua',
	'config/config.lua',
}

lua54 'yes'

escrow_ignore {
	'config/config.lua',
  }